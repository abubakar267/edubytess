class EmptyField(Exception):
    pass


class StringTooShortException(Exception):
    pass


class StringTooLongException(Exception):
    pass


class Unauthorized(Exception):
    pass


class Forbidden(Exception):
    pass
