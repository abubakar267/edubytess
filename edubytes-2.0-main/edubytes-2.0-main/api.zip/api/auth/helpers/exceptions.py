class RequiredExists(Exception):
    pass


class EmptyField(Exception):
    pass


class HTTP_HEADER_MISSING(Exception):
    pass
